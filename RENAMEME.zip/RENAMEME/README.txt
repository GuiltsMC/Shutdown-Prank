These are a set of files to use if you want to mess with your friends. The vbs file will run an error message saying your friend has to run the bat file,
and a second script will run to shutdown the users computer. I named the file (GAME_NAME) for you to rename with a game (Minecraft Hacks, Fortnite Hacks, etc.)
and once the file has been run, it will immediately begin to shutdown their computer. PLEASE NOTE: the .bat file will take 150 seconds to go into effect. 
Also make sure this readme file is removed from the folder or else your friend will see the troll :/ 

DO NOT USE FOR MALICIOUS REASONS. OTHER THAN FORCE SHUTTING DOWN YOUR FRIENDS COMPUTER. BECAUSE THAT'S FUNNY.